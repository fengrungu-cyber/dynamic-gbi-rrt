"""Benchmark / ablation runner.

Examples
  python experiments/run_benchmark.py --runs 30                      # comparison (Fig. 5)
  python experiments/run_benchmark.py --runs 30 --ablation           # ablation (Table 5)
  python experiments/run_benchmark.py --runs 3 --scenarios s2_corridor --methods proposed gbi_rrt
"""
import argparse, os, sys, csv, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np
from scipy import stats
from dynamic_gbi_rrt import Config
from dynamic_gbi_rrt.baselines import make_method
from dynamic_gbi_rrt.sim import World, run_episode, SCENARIOS

COMPARE = ["proposed", "gbi_rrt", "rrt_star", "dstar_lite"]
ABLATION = ["proposed", "abl_no_amu", "abl_no_pred", "abl_no_pra", "abl_no_edr"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=30)
    ap.add_argument("--scenarios", nargs="+", default=SCENARIOS)
    ap.add_argument("--methods", nargs="+", default=None)
    ap.add_argument("--ablation", action="store_true")
    ap.add_argument("--out", default="results")
    a = ap.parse_args()
    methods = a.methods or (ABLATION if a.ablation else COMPARE)
    os.makedirs(a.out, exist_ok=True)
    cfg = Config(); rows = []
    tag = "ablation" if a.ablation else "comparison"
    for sc in a.scenarios:
        for m in methods:
            for seed in range(a.runs):
                w = World(sc, cfg, seed); w.step()
                nav = make_method(m, w.observe(), w.goal, cfg, seed)
                t0 = time.time(); r = run_episode(w, nav, cfg)
                r.update(scenario=sc, method=m, seed=seed); rows.append(r)
                print(f"{sc:18s} {m:12s} seed={seed:3d} {r['status']:9s} t={r['time']:6.1f}s "
                      f"len={r['length']:5.2f} plan={r['plan_ms']:6.1f}ms ({time.time()-t0:.1f}s wall)", flush=True)
    keys = ["scenario", "method", "seed", "status", "time", "length", "plan_ms", "replans"]
    with open(os.path.join(a.out, f"{tag}_runs.csv"), "w", newline="") as f:
        wr = csv.DictWriter(f, keys); wr.writeheader(); wr.writerows([{k: r[k] for k in keys} for r in rows])
    summarize(rows, a.scenarios, methods, os.path.join(a.out, f"{tag}_summary.md"))


def summarize(rows, scenarios, methods, path):
    lines = []
    for sc in scenarios:
        lines += [f"\n### {sc}\n", "| Method | SR (%) | CR (%) | Time (s) | Path (m) | Plan (ms) | p(SR) | p(time) |",
                  "|---|---|---|---|---|---|---|---|"]
        ref = [r for r in rows if r["scenario"] == sc and r["method"] == "proposed"]
        for m in methods:
            R = [r for r in rows if r["scenario"] == sc and r["method"] == m]
            if not R:
                continue
            n = len(R); s = [r for r in R if r["status"] == "success"]
            sr = 100 * len(s) / n; cr = 100 * sum(r["status"] == "collision" for r in R) / n
            ms = lambda k: (f"{np.mean([r[k] for r in s]):.2f} ± {np.std([r[k] for r in s], ddof=1):.2f}"
                            if len(s) > 1 else "n/a")
            pm = f"{np.mean([r['plan_ms'] for r in R]):.1f} ± {np.std([r['plan_ms'] for r in R], ddof=1):.1f}" if n > 1 else "n/a"
            p_sr = p_t = "-"
            if m != "proposed" and ref:
                tab = [[len(s), n - len(s)],
                       [sum(r["status"] == "success" for r in ref), len(ref) - sum(r["status"] == "success" for r in ref)]]
                p_sr = f"{stats.fisher_exact(tab)[1]:.3g}"
                sa = [r["time"] for r in s]; sb = [r["time"] for r in ref if r["status"] == "success"]
                if len(sa) > 1 and len(sb) > 1:
                    p_t = f"{stats.ttest_ind(sa, sb, equal_var=False)[1]:.3g}"
            lines.append(f"| {m} | {sr:.1f} | {cr:.1f} | {ms('time')} | {ms('length')} | {pm} | {p_sr} | {p_t} |")
    text = "\n".join(lines); open(path, "w").write(text); print(text)


if __name__ == "__main__":
    main()
