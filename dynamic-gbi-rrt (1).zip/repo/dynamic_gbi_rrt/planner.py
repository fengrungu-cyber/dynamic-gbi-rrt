"""Dynamic GBI-RRT planner (Sec. 3.6, Eqs. 28-30, 37-42).

NOTE: the base GBI-RRT of Sun et al. is simplified here to goal-biased RRT
sampling; the three contributions of the manuscript (prediction-guided sampling,
uncertainty-aware risk, dual-trigger replanning) are implemented as described.
"""
import numpy as np
from scipy.ndimage import binary_dilation, distance_transform_edt
from .risk import RiskField


class DynamicGBIRRT:
    def __init__(self, cfg, rng=None):
        self.cfg = cfg
        self.rng = rng or np.random.default_rng(0)

    # ---------- map helpers ----------
    def set_map(self, occ):
        c = self.cfg
        self.free = ~(distance_transform_edt(~occ) * c.resolution < c.robot_radius + c.safety_margin)
        self.shape = occ.shape

    def _cell(self, p):
        r = self.cfg.resolution
        return int(p[1] / r), int(p[0] / r)

    def point_free(self, p):
        i, j = self._cell(p)
        return 0 <= i < self.shape[0] and 0 <= j < self.shape[1] and self.free[i, j]

    def seg_free(self, a, b):
        r = self.cfg.resolution
        n = max(2, int(np.linalg.norm(b - a) / (r * 0.5)))
        pts = a + (b - a) * np.linspace(0, 1, n)[:, None]
        i = (pts[:, 1] / r).astype(int); j = (pts[:, 0] / r).astype(int)
        if i.min() < 0 or j.min() < 0 or i.max() >= self.shape[0] or j.max() >= self.shape[1]:
            return False
        return bool(self.free[i, j].all())

    # ---------- sampling, Eqs. (28)-(29) ----------
    def sample(self, goal, predictions):
        c = self.cfg
        W = self.shape[1] * c.resolution; H = self.shape[0] * c.resolution
        u = self.rng.random()
        if u < c.p_goal:
            return goal.copy()
        use_safe = u < c.p_goal + c.p_safe
        for _ in range(30):
            x = self.rng.random(2) * [W, H]
            if not use_safe:
                return x
            ok = all(np.linalg.norm(x - ph) >= r + c.delta_s
                     for preds in predictions for (ph, _, r) in preds)
            if ok:
                return x
        return x

    # ---------- cost, Eqs. (37)-(40) ----------
    def path_cost(self, path):
        c = self.cfg
        P = np.asarray(path)
        D_env = np.hypot(self.shape[0], self.shape[1]) * c.resolution
        J_len = np.sum(np.linalg.norm(np.diff(P, axis=0), axis=1)) / D_env
        if len(P) > 2:
            a = P[1:-1] - P[:-2]; b = P[2:] - P[1:-1]
            cos = np.sum(a * b, 1) / (np.linalg.norm(a, axis=1) * np.linalg.norm(b, axis=1) + 1e-9)
            J_sm = np.sum(np.arccos(np.clip(cos, -1, 1))) / ((len(P) - 2) * np.pi)
        else:
            J_sm = 0.0
        return J_len, J_sm

    def plan(self, start, goal, predictions, gate=1.0):
        c = self.cfg
        risk = RiskField(predictions, c)
        nodes = [np.asarray(start, float)]; parent = [-1]
        arr = np.zeros((c.max_iters + 2, 2)); arr[0] = nodes[0]
        for _ in range(c.max_iters):
            x = self.sample(goal, predictions)
            k = int(np.argmin(((arr[:len(nodes)] - x) ** 2).sum(1)))
            d = x - nodes[k]; dist = np.linalg.norm(d)
            if dist < 1e-9:
                continue
            new = nodes[k] + c.step * d / dist if dist > c.step else x        # Eq. (30)
            if not self.seg_free(nodes[k], new):
                continue
            if c.use_risk and risk(new) > max(gate * c.R_th, risk(nodes[0])):                       # risk gate
                continue
            nodes.append(new); parent.append(k); arr[len(nodes) - 1] = new
            if np.linalg.norm(new - goal) < c.goal_tol and self.seg_free(new, goal):
                path = [goal]; i = len(nodes) - 1
                while i >= 0:
                    path.append(nodes[i]); i = parent[i]
                return self.shortcut(path[::-1], risk)
        return None

    def shortcut(self, path, risk):
        """Remove redundant way-points (keeps risk-free segments only)."""
        out = [path[0]]; i = 0
        while i < len(path) - 1:
            j = len(path) - 1
            while j > i + 1 and not (self.seg_free(path[i], path[j]) and
                                     (not self.cfg.use_risk or
                                      max(risk(p) for p in self._samples([path[i], path[j]], 0.15)) <= self.cfg.R_th)):
                j -= 1
            out.append(path[j]); i = j
        return out

    def _samples(self, pts, spacing=0.1):
        """Points sampled densely along a way-point polyline."""
        out = [np.asarray(pts[0])]
        for a, b in zip(pts[:-1], pts[1:]):
            n = max(1, int(np.linalg.norm(b - a) / spacing))
            out += [a + (b - a) * t for t in np.linspace(0, 1, n + 1)[1:]]
        return np.array(out)

    # ---------- dual-trigger replanning, Eqs. (41)-(42) ----------
    def replan_needed(self, remaining, predictions):
        c = self.cfg
        if remaining is None or len(remaining) < 2:
            return True
        collides = any(not self.seg_free(a, b) for a, b in zip(remaining[:-1], remaining[1:]))
        if collides:
            return True
        if not (c.use_edr and c.use_pred):
            return False
        risk = RiskField(predictions, c)
        S = self._samples(remaining)
        R_cur = max(risk(p) for p in S) if c.use_risk else 0.0
        d_min = np.inf
        if len(risk.pos):
            d_min = float(np.sqrt(((S[:, None, :] - risk.pos[None]) ** 2).sum(-1)).min())
        return R_cur > c.R_th or d_min < c.d_safe            # Eq. (41)

    # ---------- RRT* baseline (Karaman & Frazzoli) ----------
    def plan_rrt_star(self, start, goal, iters=1200, gamma=1.0):
        c = self.cfg
        arr = np.zeros((iters + 2, 2)); arr[0] = start
        parent = [-1]; cost = [0.0]; n = 1
        for _ in range(iters):
            x = goal.copy() if self.rng.random() < c.p_goal else \
                self.rng.random(2) * [self.shape[1] * c.resolution, self.shape[0] * c.resolution]
            d2 = ((arr[:n] - x) ** 2).sum(1); k = int(np.argmin(d2)); dist = d2[k] ** 0.5
            if dist < 1e-9:
                continue
            new = arr[k] + c.step * (x - arr[k]) / dist if dist > c.step else x
            if not self.seg_free(arr[k], new):
                continue
            rad = max(c.step * 2, gamma * np.sqrt(np.log(n + 1) / (n + 1)) * 4)
            dn = np.sqrt(((arr[:n] - new) ** 2).sum(1)); near = np.where(dn < rad)[0]
            best, bc = k, cost[k] + np.linalg.norm(new - arr[k])
            for j in near:
                cj = cost[j] + dn[j]
                if cj < bc and self.seg_free(arr[j], new):
                    best, bc = int(j), cj
            arr[n] = new; parent.append(best); cost.append(bc); idx = n; n += 1
            for j in near:                                            # rewire
                cj = bc + dn[j]
                if cj < cost[j] - 1e-9 and self.seg_free(new, arr[j]):
                    parent[j] = idx; cost[j] = cj
        dg = np.sqrt(((arr[:n] - goal) ** 2).sum(1))
        cand = [i for i in np.argsort(cost + dg) if dg[i] < c.goal_tol * 2 and self.seg_free(arr[i], goal)]
        if not cand:
            return None
        i = int(cand[0]); path = [goal.copy()]
        while i >= 0:
            path.append(arr[i].copy()); i = parent[i]
        return path[::-1]
