"""Event-driven integration loop (Algorithm 1) with differential-drive control."""
import time
import numpy as np
from .mapping import AdaptiveMap
from .tracking import ObstacleTracker
from .prediction import process_noise, predict
from .planner import DynamicGBIRRT
from .controller import PurePursuit


class Navigator:
    """Proposed framework. Module switches in cfg allow ablation / GBI-RRT baseline."""

    def __init__(self, first_obs, goal, cfg, seed=0):
        self.cfg = cfg
        self.map = AdaptiveMap(first_obs, cfg)
        self.tracker = ObstacleTracker(cfg)
        self.planner = DynamicGBIRRT(cfg, np.random.default_rng(seed))
        self.ctrl = PurePursuit(cfg)
        self.goal = np.asarray(goal, float)
        self.path = None; self.predictions = []
        self.n_replans = 0; self.plan_times = []; self.k = 0

    def _replan_due(self, pose):
        c = self.cfg
        if self.path is None or len(self.path) < 2:
            return True
        remaining = [pose[:2]] + self.path[1:]
        if self.planner.replan_needed(remaining, self.predictions):
            return True
        return (not c.use_edr) and c.periodic_steps > 0 and self.k % c.periodic_steps == 0

    def step(self, p_obs, pose):
        c = self.cfg; self.k += 1
        omega, T = self.map.update(p_obs)
        if T and c.use_pred:                                   # event: prediction
            dets = self.tracker.detect(omega, p_obs)
            tracks = self.tracker.step(dets, lambda t: process_noise(t, c))
            self.predictions = [predict(t, c) for t in tracks if t.age >= 2]
        self.planner.set_map(self.map.occupied())
        if self._replan_due(pose):
            t0 = time.perf_counter()
            new = self.planner.plan(pose[:2], self.goal, self.predictions)
            if new is None and self.path is None:               # fallback: relax the risk gate
                new = self.planner.plan(pose[:2], self.goal, self.predictions, gate=2.0)
            self.plan_times.append(time.perf_counter() - t0); self.n_replans += 1
            if new is not None:
                self.path = new
        if self.path is not None:                              # drop reached way-points
            while len(self.path) > 1 and np.linalg.norm(self.path[0] - pose[:2]) < c.waypoint_tol:
                self.path.pop(0)
        v, w = self.ctrl.command(pose, self.path)
        return v, w, bool(T)

    def reached(self, pose):
        return np.linalg.norm(pose[:2] - self.goal) < self.cfg.goal_tol
