"""2-D simulator: ground-truth world, noisy occupancy observations, 3 scenarios.

LRBPF-SLAM is replaced by an observation model that returns the occupancy-probability grid
(a SLAM module would output) with isolated speckle noise.
"""
import numpy as np
from .controller import integrate

SCENARIOS = ["s1_static", "s2_corridor", "s3_highly_dynamic"]


class World:
    def __init__(self, scenario, cfg, seed=0, noise=0.002):
        self.cfg, self.noise = cfg, noise
        self.rng = np.random.default_rng(10_000 + seed)
        r = cfg.resolution
        self.scenario = scenario
        if scenario == "s1_static":
            self.W, self.H = 8.0, 8.0
        elif scenario == "s2_corridor":
            self.W, self.H = 10.0, 3.0
        elif scenario == "s3_highly_dynamic":
            self.W, self.H = 8.0, 8.0
        else:
            raise ValueError(scenario)
        self.nx, self.ny = int(self.W / r), int(self.H / r)
        s = np.zeros((self.ny, self.nx), bool)
        s[0, :] = s[-1, :] = s[:, 0] = s[:, -1] = True
        def box(x0, x1, y0, y1):
            s[int(y0 / r):int(y1 / r), int(x0 / r):int(x1 / r)] = True
        movers = []
        if scenario == "s1_static":
            box(3.8, 4.2, 2.5, 5.5); box(1.0, 2.4, 3.0, 3.6); box(5.5, 6.5, 5.5, 6.1)
            self.start, self.goal = np.array([1.0, 1.0, 0.8]), np.array([7.0, 7.0])
        elif scenario == "s2_corridor":
            box(4.0, 4.5, 0.0, 0.9); box(6.0, 6.5, 2.1, 3.0)
            self.start, self.goal = np.array([0.8, 1.5, 0.0]), np.array([9.2, 1.5])
            for x, y, vx in [(8.0, 1.2, -0.18), (5.2, 1.8, 0.15)]:
                movers.append(dict(p=np.array([x, y]) + self.rng.normal(0, .1, 2),
                                   v=np.array([vx, 0.0]), r=0.22))
        else:
            box(3.5, 4.5, 3.5, 4.5)
            self.start, self.goal = np.array([1.0, 1.0, 0.8]), np.array([7.0, 7.0])
            for _ in range(4):
                while True:
                    p = self.rng.uniform(1.5, 6.5, 2)
                    if np.linalg.norm(p - self.start[:2]) > 1.8 and np.linalg.norm(p - self.goal) > 1.8:
                        break
                ang = self.rng.uniform(0, 2 * np.pi); sp = self.rng.uniform(0.08, 0.20)
                movers.append(dict(p=p, v=sp * np.array([np.cos(ang), np.sin(ang)]), r=0.22,
                                   t_turn=self.rng.uniform(2, 5)))
        self.static, self.movers, self.t = s, movers, 0.0
        self.yy, self.xx = np.mgrid[:self.ny, :self.nx]
        self.occ = self._render()

    def _render(self):
        r = self.cfg.resolution; occ = self.static.copy()
        for m in self.movers:
            occ |= np.hypot((self.xx + .5) * r - m["p"][0], (self.yy + .5) * r - m["p"][1]) < m["r"]
        return occ

    def step(self):
        c = self.cfg; r = c.resolution; self.t += c.dt
        for m in self.movers:
            if "t_turn" in m:                                   # sudden direction change
                m["t_turn"] -= c.dt
                if m["t_turn"] <= 0:
                    ang = self.rng.uniform(0, 2 * np.pi); sp = self.rng.uniform(0.08, 0.20)
                    m["v"] = sp * np.array([np.cos(ang), np.sin(ang)]); m["t_turn"] = self.rng.uniform(2, 5)
            nxt = m["p"] + m["v"] * c.dt
            for k in range(2):                                  # bounce off static cells
                q = m["p"].copy(); q[k] = nxt[k]
                i, j = int((q[1] + np.sign(m["v"][1]) * m["r"] * (k == 1)) / r), \
                       int((q[0] + np.sign(m["v"][0]) * m["r"] * (k == 0)) / r)
                if not (0 <= i < self.ny and 0 <= j < self.nx) or self.static[i, j]:
                    m["v"][k] *= -1
            m["p"] = m["p"] + m["v"] * c.dt
        self.occ = self._render()

    def observe(self):
        p = np.where(self.occ, 0.95, 0.05)
        flip = self.rng.random(p.shape) < self.noise            # isolated speckle noise
        return np.where(flip, 1 - p, p)

    def collides(self, pose):
        r = self.cfg.resolution; rad = self.cfg.robot_radius * 0.9
        i0, j0 = int(pose[1] / r), int(pose[0] / r); k = int(rad / r) + 1
        for i in range(max(0, i0 - k), min(self.ny, i0 + k + 1)):
            for j in range(max(0, j0 - k), min(self.nx, j0 + k + 1)):
                if self.occ[i, j] and np.hypot((j + .5) * r - pose[0], (i + .5) * r - pose[1]) < rad:
                    return True
        return False


def run_episode(world, navigator, cfg, max_time=240.0):
    """Returns dict of metrics for one navigation episode."""
    pose = world.start.copy(); length = 0.0
    n = int(max_time / cfg.dt); status = "timeout"
    for k in range(n):
        world.step()
        v, w, _ = navigator.step(world.observe(), pose)
        new = integrate(pose, v, w, cfg.dt)
        length += np.linalg.norm(new[:2] - pose[:2]); pose = new
        if world.collides(pose):
            status = "collision"; break
        if navigator.reached(pose):
            status = "success"; break
    pt = getattr(navigator, "plan_times", [])
    return dict(status=status, time=(k + 1) * cfg.dt, length=length,
                plan_ms=1000 * float(np.mean(pt)) if pt else 0.0,
                replans=len(pt))
