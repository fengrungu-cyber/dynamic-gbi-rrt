"""D* Lite (Koenig & Likhachev, 2002) on an 8-connected occupancy grid."""
import heapq
from math import hypot, inf
import numpy as np

SQRT2 = 2 ** 0.5
_N8 = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]


class DStarLite:
    def __init__(self, free, start, goal):
        self.free = free.copy(); self.shape = free.shape
        self.g = np.full(self.shape, inf); self.rhs = np.full(self.shape, inf)
        self.U = []; self.inU = {}; self.km = 0.0
        self.start = start; self.last = start; self.goal = goal
        self.rhs[goal] = 0.0
        self._push(goal)
        self.compute()

    # --- helpers ---
    def h(self, a, b):
        return hypot(a[0] - b[0], a[1] - b[1])

    def key(self, s):
        m = min(self.g[s], self.rhs[s])
        # rounding avoids floating-point ties breaking the key ordering
        return (round(m + self.h(self.start, s) + self.km, 6), round(m, 6))

    def _push(self, s):
        k = self.key(s); self.inU[s] = k; heapq.heappush(self.U, (k[0], k[1], s))

    def nbrs(self, s):
        for di, dj in _N8:
            t = (s[0] + di, s[1] + dj)
            if 0 <= t[0] < self.shape[0] and 0 <= t[1] < self.shape[1]:
                yield t

    def cost(self, a, b):
        if not (self.free[a] and self.free[b]):
            return inf
        if a[0] != b[0] and a[1] != b[1]:                     # no corner cutting
            if not (self.free[a[0], b[1]] and self.free[b[0], a[1]]):
                return inf
            return SQRT2
        return 1.0

    def update_vertex(self, u):
        if u != self.goal:
            self.rhs[u] = min((self.cost(u, s) + self.g[s] for s in self.nbrs(u)), default=inf)
        self.inU.pop(u, None)
        if self.g[u] != self.rhs[u]:
            self._push(u)

    def compute(self):
        while True:
            while self.U and self.inU.get(self.U[0][2]) != (self.U[0][0], self.U[0][1]):
                heapq.heappop(self.U)                          # stale entries
            if not self.U:
                break
            k_old = (self.U[0][0], self.U[0][1])
            if not (k_old < self.key(self.start) or self.rhs[self.start] != self.g[self.start]):
                break
            _, _, u = heapq.heappop(self.U); self.inU.pop(u, None)
            k_new = self.key(u)
            if k_old < k_new:
                self._push(u)
            elif self.g[u] > self.rhs[u]:
                self.g[u] = self.rhs[u]
                for p in self.nbrs(u):
                    self.update_vertex(p)
            else:
                self.g[u] = inf
                self.update_vertex(u)
                for p in self.nbrs(u):
                    self.update_vertex(p)

    # --- public ---
    def update_map(self, free_new, start):
        changed = np.argwhere(free_new != self.free)
        self.km += self.h(self.last, start); self.last = start; self.start = start
        self.free = free_new.copy()
        touched = set()
        for c in changed:
            c = (int(c[0]), int(c[1])); touched.add(c); touched.update(self.nbrs(c))
        for v in touched:
            self.update_vertex(v)
        self.compute()
        return len(changed)

    def path(self, max_len=2000):
        if self.g[self.start] == inf:
            return None
        s = self.start; out = [s]
        for _ in range(max_len):
            if s == self.goal:
                return out
            nxt = min(self.nbrs(s), key=lambda t: self.cost(s, t) + self.g[t])
            if self.cost(s, nxt) + self.g[nxt] == inf:
                return None
            s = nxt; out.append(s)
        return None
