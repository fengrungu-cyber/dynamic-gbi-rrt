"""Baseline methods and a factory for all compared / ablated methods."""
import time
import numpy as np
from copy import deepcopy
from scipy.ndimage import distance_transform_edt, median_filter
from .navigator import Navigator
from .planner import DynamicGBIRRT
from .controller import PurePursuit
from .dstar_lite import DStarLite


class RRTStarNavigator:
    """RRT* on the (median-filtered) SLAM map; replans only when the path is blocked."""

    def __init__(self, first_obs, goal, cfg, seed=0):
        self.cfg = cfg; self.goal = np.asarray(goal, float)
        self.planner = DynamicGBIRRT(cfg, np.random.default_rng(seed))
        self.ctrl = PurePursuit(cfg); self.path = None
        self.map_p = median_filter(first_obs.astype(float), size=3)
        self.plan_times = []; self.n_replans = 0

    def step(self, p_obs, pose):
        c = self.cfg
        self.map_p = median_filter(p_obs, size=3)
        self.planner.set_map(self.map_p > 0.5)
        blocked = self.path is None or len(self.path) < 2 or any(
            not self.planner.seg_free(a, b) for a, b in zip([pose[:2]] + self.path[1:-1], self.path[1:]))
        if blocked:
            t0 = time.perf_counter()
            new = self.planner.plan_rrt_star(pose[:2], self.goal)
            self.plan_times.append(time.perf_counter() - t0); self.n_replans += 1
            if new is not None:
                self.path = new
        if self.path is not None:
            while len(self.path) > 1 and np.linalg.norm(self.path[0] - pose[:2]) < c.waypoint_tol:
                self.path.pop(0)
        v, w = self.ctrl.command(pose, self.path)
        return v, w, False

    def reached(self, pose):
        return np.linalg.norm(pose[:2] - self.goal) < self.cfg.goal_tol


class DStarLiteNavigator:
    """Grid-based incremental replanning on the (median-filtered) SLAM map."""

    def __init__(self, first_obs, goal, cfg, seed=0):
        self.cfg = cfg; self.goal = np.asarray(goal, float); self.ctrl = PurePursuit(cfg)
        self.ds = None; self.path = None; self.plan_times = []; self.n_replans = 0

    def _free(self, p):
        occ = median_filter(p, size=3) > 0.5
        return ~(distance_transform_edt(~occ) * self.cfg.resolution < self.cfg.robot_radius + self.cfg.safety_margin)

    def _cell(self, x):
        r = self.cfg.resolution
        return (int(x[1] / r), int(x[0] / r))

    def step(self, p_obs, pose):
        c = self.cfg; r = c.resolution
        free = self._free(p_obs); s = self._cell(pose[:2]); g = self._cell(self.goal)
        t0 = time.perf_counter()
        if self.ds is None:
            self.ds = DStarLite(free, s, g)
        else:
            self.ds.update_map(free, s)
        cells = self.ds.path()
        self.plan_times.append(time.perf_counter() - t0); self.n_replans += 1
        if cells is not None:
            pts = [np.array([(j + .5) * r, (i + .5) * r]) for i, j in cells[::2]]
            pts.append(self.goal.copy()); self.path = pts
        v, w = self.ctrl.command(pose, self.path)
        return v, w, False

    def reached(self, pose):
        return np.linalg.norm(pose[:2] - self.goal) < self.cfg.goal_tol


METHODS = ["proposed", "gbi_rrt", "rrt_star", "dstar_lite",
           "abl_no_amu", "abl_no_pred", "abl_no_pra", "abl_no_edr"]


def make_method(name, first_obs, goal, cfg, seed=0):
    c = deepcopy(cfg)
    if name == "proposed":
        pass
    elif name == "gbi_rrt":     # static-map GBI-RRT baseline: no AMU / prediction / PRA / EDR
        c.use_amu = c.use_pred = c.use_risk = c.use_edr = False
    elif name == "abl_no_amu":
        c.use_amu = False
    elif name == "abl_no_pred":
        c.use_pred = False
    elif name == "abl_no_pra":
        c.use_risk = False
    elif name == "abl_no_edr":
        c.use_edr = False; c.periodic_steps = 10
    elif name == "rrt_star":
        return RRTStarNavigator(first_obs, goal, c, seed)
    elif name == "dstar_lite":
        return DStarLiteNavigator(first_obs, goal, c, seed)
    else:
        raise ValueError(name)
    return Navigator(first_obs, goal, c, seed)
