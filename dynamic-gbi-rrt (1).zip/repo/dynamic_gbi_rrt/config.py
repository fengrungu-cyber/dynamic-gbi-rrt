"""Parameters of the framework.

Values marked [Table 2] are taken from the manuscript (Table 2).
Values marked [assumed] are NOT specified in the manuscript; they are
reasonable defaults and must be replaced by the values used in your experiments.
"""
from dataclasses import dataclass


@dataclass
class Config:
    # --- grid map ---
    resolution: float = 0.1            # m / cell [assumed]
    robot_radius: float = 0.12         # m (TurtleBot3 Burger ~0.105) [assumed]
    safety_margin: float = 0.10        # extra inflation of static/map obstacles (m) [assumed]
    # --- adaptive map updating (Sec. 3.4) ---
    delta: float = 0.30                # change threshold, Eq. (3) [assumed]
    eps_s: float = 0.15                # spatial consistency threshold, Eq. (10) [Table 2]
    N_p: int = 5                       # persistence window, Eq. (13) [assumed]
    eta_trigger: float = 0.002         # map-update ratio trigger, Eq. (15) [assumed]
    # --- tracking / prediction (Sec. 3.3, 3.5) ---
    dt: float = 0.2                    # s [assumed]
    gate: float = 0.6                  # association gate (m) [assumed]
    L: int = 10                        # prediction horizon (steps) [Table 2]
    alpha_a: float = 0.5               # MCI decay, Eq. (20) [assumed]
    eta_a: float = 4.0                 # process-noise gain, Eq. (22) [assumed]
    q0: float = 0.05                   # nominal process noise std [assumed]
    r_meas: float = 0.10               # measurement noise std (m) [assumed]
    kappa: float = 2.0                 # safety radius factor, Eq. (25) (~95 %) [paper text]
    # --- risk (Sec. 3.6.2) ---
    r0: float = 0.25                   # base influence radius, Eq. (33) [assumed]
    beta_r: float = 1.0                # uncertainty gain, Eq. (33) [assumed]
    lambda_H: float = 0.80             # entropy-confidence factor, Eq. (34) [Table 2, "lambda_H"]
    mu: float = 0.60                   # uncertainty risk gain, Eq. (35) [Table 2, "mu"]
    # --- planner (Sec. 3.6) ---
    p_goal: float = 0.25               # goal bias [Table 2]
    p_safe: float = 0.35               # prediction-guided sampling prob. [assumed]
    step: float = 0.20                 # tree expansion step (m) [Table 2]
    delta_s: float = 0.10              # sampling margin, Eq. (28) [assumed]
    goal_tol: float = 0.20             # m [assumed]
    max_iters: int = 2000              # [assumed]
    w_len: float = 0.45                # alpha in Eq. (37) [Table 2 alpha]
    w_risk: float = 0.35               # beta  in Eq. (37) [Table 2 beta]
    w_smooth: float = 0.20             # gamma in Eq. (37) [Table 2 gamma]
    d_safe: float = 0.35               # safety distance (m) [Table 2]
    R_th: float = 0.60                 # replanning risk threshold [Table 2]
    # --- robot / controller ---
    v_max: float = 0.20                # m/s [assumed]
    w_max: float = 1.0                 # rad/s [assumed]
    lookahead: float = 0.30            # pure-pursuit look-ahead (m) [assumed]
    waypoint_tol: float = 0.15         # m [assumed]
    # --- module switches (ablation, Table 5) ---
    use_amu: bool = True               # adaptive map updating
    use_pred: bool = True              # MCI-based prediction
    use_risk: bool = True              # predictive risk assessment (PRA)
    use_edr: bool = True               # event-driven (dual-trigger) replanning
    periodic_steps: int = 0            # replan period when use_edr=False (0 = only if blocked)
