"""Differential-drive pure-pursuit controller and unicycle kinematics."""
import numpy as np


def integrate(pose, v, w, dt):
    x, y, th = pose
    return np.array([x + v * np.cos(th) * dt, y + v * np.sin(th) * dt,
                     (th + w * dt + np.pi) % (2 * np.pi) - np.pi])


class PurePursuit:
    def __init__(self, cfg):
        self.cfg = cfg

    def command(self, pose, path):
        """path: list of (x, y) way-points ahead of the robot. Returns (v, w)."""
        c = self.cfg
        if path is None or len(path) == 0:
            return 0.0, 0.0
        pos = pose[:2]
        target = path[-1]
        for p in path:
            if np.linalg.norm(p - pos) >= c.lookahead:
                target = p; break
        d = target - pos
        err = (np.arctan2(d[1], d[0]) - pose[2] + np.pi) % (2 * np.pi) - np.pi
        w = float(np.clip(2.0 * err, -c.w_max, c.w_max))
        dist_goal = np.linalg.norm(path[-1] - pos)
        v = c.v_max * max(0.0, np.cos(err)) * min(1.0, dist_goal / 0.5)
        if abs(err) > 1.0:
            v = 0.0                                  # rotate in place
        return float(v), w
