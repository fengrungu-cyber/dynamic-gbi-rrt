"""Uncertainty-aware predictive risk (Sec. 3.6.2, Eqs. 31-36)."""
import numpy as np


class RiskField:
    """Pre-computes everything that does not depend on the candidate node."""

    def __init__(self, predictions, cfg):
        self.cfg = cfg
        pos, r, wl, conf = [], [], [], []
        L = cfg.L
        w = np.arange(L, 0, -1, dtype=float); w /= w.sum()      # w_l, decaying, sum 1 [assumed]
        for preds in predictions:
            for l, (ph, Sig, _) in enumerate(preds):
                pos.append(ph)
                r.append(cfg.r0 + cfg.beta_r * np.sqrt(np.trace(Sig)))          # Eq. (33)
                C = np.exp(-cfg.lambda_H * np.log(np.linalg.det(Sig) + 1e-12))  # Eq. (34)
                C = float(np.clip(C, 0.0, 1.0))   # keep 1-C in [0,1] (see README)
                conf.append(1 + cfg.mu * (1 - C))                               # Eq. (35) factor
                wl.append(w[min(l, L - 1)])
        self.pos = np.array(pos).reshape(-1, 2); self.r = np.array(r)
        self.k = np.array(conf) * np.array(wl)

    def __call__(self, p):
        if len(self.pos) == 0:
            return 0.0
        d2 = ((self.pos - p) ** 2).sum(1)                       # Eq. (32), squared
        rho = np.exp(-d2 / (2 * self.r ** 2))                   # Eq. (31)
        return float((self.k * rho).sum())                      # Eq. (36)


def node_risk(p, predictions, cfg):
    return RiskField(predictions, cfg)(p)
