"""Cluster detection inside Omega_t and Kalman tracking (Sec. 3.3, Eqs. 5-8)."""
import numpy as np
from scipy.ndimage import label, center_of_mass


def cv_matrix(dt):
    A = np.eye(4)
    A[0, 2] = A[1, 3] = dt
    return A


class Track:
    def __init__(self, pos, cfg):
        self.s = np.array([pos[0], pos[1], 0.0, 0.0])
        self.P = np.diag([cfg.r_meas ** 2] * 2 + [1.0, 1.0])
        self.v_prev = np.zeros(2)
        self.Q = None
        self.age = 0
        self.miss = 0


class ObstacleTracker:
    def __init__(self, cfg):
        self.cfg = cfg
        self.tracks = []

    def detect(self, omega, p_obs=None):
        """Centroids (world coords) of 8-connected clusters of changed cells.
        If p_obs is given, only cells that became occupied are clustered."""
        if p_obs is not None:
            omega = omega & (p_obs > 0.5)
        lab, n = label(omega, structure=np.ones((3, 3)))
        if n == 0:
            return []
        cs = center_of_mass(omega, lab, range(1, n + 1))
        res = self.cfg.resolution
        return [np.array([(c[1] + 0.5) * res, (c[0] + 0.5) * res]) for c in cs]

    def step(self, detections, Q_fn):
        """Nearest-neighbour association + Kalman update. Q_fn(track)->Q."""
        cfg = self.cfg
        A = cv_matrix(cfg.dt)
        H = np.zeros((2, 4)); H[0, 0] = H[1, 1] = 1
        R = np.eye(2) * cfg.r_meas ** 2
        unused = list(range(len(detections)))
        for t in self.tracks:
            t.v_prev = t.s[2:].copy()
            t.Q = Q_fn(t)
            t.s = A @ t.s
            t.P = A @ t.P @ A.T + t.Q                         # predict
            if unused:
                d = [np.linalg.norm(detections[j] - t.s[:2]) for j in unused]
                k = int(np.argmin(d))
                if d[k] < cfg.gate:
                    z = detections[unused.pop(k)]
                    S = H @ t.P @ H.T + R
                    K = t.P @ H.T @ np.linalg.inv(S)
                    t.s = t.s + K @ (z - H @ t.s)
                    t.P = (np.eye(4) - K @ H) @ t.P
                    t.age += 1; t.miss = 0
                    continue
            t.miss += 1
        self.tracks = [t for t in self.tracks if t.miss <= 3]     # prune lost tracks
        for j in unused:                                      # new tracks
            self.tracks.append(Track(detections[j], cfg))
        return self.tracks
