"""MCI-based constant-velocity prediction (Sec. 3.5, Eqs. 17-27)."""
import numpy as np
from .tracking import cv_matrix


def mci(track, cfg):
    a = (track.s[2:] - track.v_prev) / cfg.dt          # Eqs. (18)-(19)
    a_hat = float(np.hypot(*a))                        # Eq. (17)
    return float(np.exp(-cfg.alpha_a * a_hat))         # Eq. (20), in (0, 1]


def process_noise(track, cfg):
    q0 = np.diag([0, 0, cfg.q0 ** 2, cfg.q0 ** 2]) + np.diag([1e-6] * 4)
    return (1 + cfg.eta_a * (1 - mci(track, cfg))) * q0     # Eq. (22)


def predict(track, cfg):
    """Returns list of (p_hat, Sigma(2x2), radius) for l = 1..L, Eqs. (23)-(25)."""
    A = cv_matrix(cfg.dt)
    Q = track.Q if track.Q is not None else process_noise(track, cfg)
    out, s, P = [], track.s.copy(), track.P.copy()
    for _ in range(cfg.L):
        s = A @ s
        P = A @ P @ A.T + Q                            # recursion equal to Eq. (24)
        Sig = P[:2, :2]
        r = cfg.kappa * np.sqrt(np.max(np.linalg.eigvalsh(Sig)))   # Eq. (25)
        out.append((s[:2].copy(), Sig.copy(), float(r)))
    return out
