"""Online adaptive map updating (Sec. 3.4, Eqs. 3, 9-16).

With cfg.use_amu = False the module degrades to a plain "SLAM map" proxy
(median-filtered observation, raw change set) used by baselines / ablation.
"""
import numpy as np
from scipy.ndimage import uniform_filter, median_filter


class AdaptiveMap:
    def __init__(self, first_obs, cfg):
        self.cfg = cfg
        first = first_obs.astype(float)
        self.p = first.copy() if cfg.use_amu else median_filter(first, size=3)
        self.n = np.zeros(self.p.shape, dtype=int)
        self.omega = np.zeros(self.p.shape, bool)
        self.trigger = False
        self.ratio = 0.0

    def update(self, p_obs):
        c = self.cfg
        if not c.use_amu:
            filt = median_filter(p_obs, size=3)
            self.omega = np.abs(filt - self.p) > c.delta
            self.p = filt
        else:
            diff = np.abs(p_obs - self.p)                        # |p_t - p_{t-1}|
            delta_m = diff > c.delta                             # Eq. (3)
            S = (uniform_filter(diff, size=3, mode="constant") * 9 - diff) / 8.0  # Eq. (9)
            self.omega = delta_m & (S > c.eps_s)                 # Eqs. (10)-(11)
            self.n = np.where(self.omega, self.n + 1, 0)         # persistence n_k
            lam = np.minimum(1.0, self.n / c.N_p)                # Eq. (13)
            self.p = np.where(self.omega, (1 - lam) * self.p + lam * p_obs, self.p)  # Eq. (12)
        self.ratio = self.omega.sum() / self.omega.size          # Eq. (14)
        self.trigger = self.ratio > c.eta_trigger                # Eq. (15)
        return self.omega, self.trigger

    def occupied(self):
        return self.p > 0.5
