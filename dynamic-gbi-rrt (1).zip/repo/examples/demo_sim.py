"""Single-episode demo with a plot.   python examples/demo_sim.py [scenario] [method]"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np
from dynamic_gbi_rrt import Config
from dynamic_gbi_rrt.baselines import make_method
from dynamic_gbi_rrt.controller import integrate
from dynamic_gbi_rrt.sim import World


def main():
    sc = sys.argv[1] if len(sys.argv) > 1 else "s3_highly_dynamic"
    method = sys.argv[2] if len(sys.argv) > 2 else "proposed"
    cfg = Config(); w = World(sc, cfg, seed=0); w.step()
    nav = make_method(method, w.observe(), w.goal, cfg, seed=0)
    pose = w.start.copy(); traj = [pose[:2].copy()]; status = "timeout"; trig = 0
    for k in range(int(240 / cfg.dt)):
        w.step(); v, wz, T = nav.step(w.observe(), pose); trig += T
        pose = integrate(pose, v, wz, cfg.dt); traj.append(pose[:2].copy())
        if w.collides(pose): status = "collision"; break
        if nav.reached(pose): status = "success"; break
    print(f"{sc} / {method}: {status} in {(k+1)*cfg.dt:.1f}s, map-triggers={trig}, replans={len(getattr(nav,'plan_times',[]))}")
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
        tr = np.array(traj)
        plt.imshow(w.static, origin="lower", extent=[0, w.W, 0, w.H], cmap="Greys")
        plt.plot(tr[:, 0], tr[:, 1], "r-"); plt.plot(*w.goal, "g*", ms=12); plt.title(f"{sc} / {method}: {status}")
        plt.savefig("demo_trajectory.png", dpi=150)
    except ImportError:
        pass


if __name__ == "__main__":
    main()
