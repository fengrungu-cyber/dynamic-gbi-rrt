import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np
from dynamic_gbi_rrt import Config
from dynamic_gbi_rrt.mapping import AdaptiveMap
from dynamic_gbi_rrt.tracking import Track
from dynamic_gbi_rrt.prediction import mci, predict
from dynamic_gbi_rrt.planner import DynamicGBIRRT
from dynamic_gbi_rrt.dstar_lite import DStarLite
from dynamic_gbi_rrt.baselines import make_method, METHODS
from dynamic_gbi_rrt.sim import World, run_episode


def test_isolated_noise_is_rejected_but_blob_is_kept():
    cfg = Config(); base = np.full((60, 60), 0.05)
    m = AdaptiveMap(base, cfg)
    obs = base.copy(); obs[5, 5] = 0.95
    omega, _ = m.update(obs)
    assert omega.sum() == 0
    obs = base.copy(); obs[20:26, 20:26] = 0.95
    omega, T = m.update(obs)
    assert omega.sum() > 0 and T


def test_mci_decreases_with_acceleration_and_in_unit_interval():
    cfg = Config(); t = Track([0, 0], cfg)
    t.s[2:] = [0.1, 0.0]; t.v_prev = np.array([0.1, 0.0]); a = mci(t, cfg)
    t.v_prev = np.array([-1.0, 0.0]); b = mci(t, cfg)
    assert 0 < b < a <= 1.0


def test_uncertainty_grows_along_horizon():
    cfg = Config(); t = Track([1, 1], cfg); t.s[2:] = [0.2, 0.0]
    p = predict(t, cfg)
    assert len(p) == cfg.L and p[-1][2] > p[0][2]


def test_planners_find_path():
    cfg = Config(); occ = np.zeros((60, 60), bool); occ[:, 30] = True; occ[25:35, 30] = False
    pl = DynamicGBIRRT(cfg); pl.set_map(occ)
    a, b = np.array([1.0, 1.0]), np.array([5.0, 5.0])
    for path in (pl.plan(a, b, []), pl.plan_rrt_star(a, b)):
        assert path is not None and np.linalg.norm(path[-1] - b) < 1e-6


def test_dstar_lite_replans_after_map_change():
    free = np.ones((20, 20), bool); ds = DStarLite(free, (1, 1), (18, 18))
    g0 = ds.g[(1, 1)]
    f2 = free.copy(); f2[5:15, 10] = False
    ds.update_map(f2, (1, 1))
    assert ds.g[(1, 1)] > g0 and ds.path() is not None


def test_all_methods_run_one_short_episode():
    cfg = Config()
    for m in METHODS:
        w = World("s2_corridor", cfg, 0); w.step()
        nav = make_method(m, w.observe(), w.goal, cfg, 0)
        r = run_episode(w, nav, cfg, max_time=6.0)
        assert r["status"] in ("success", "collision", "timeout")
