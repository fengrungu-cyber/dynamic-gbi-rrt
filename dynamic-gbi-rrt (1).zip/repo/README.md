# Dynamic GBI-RRT: event-driven navigation in dynamic indoor environments

Reference implementation of the navigation framework in the manuscript *"A Real-Time Adaptive Framework for
Mobile Robot Navigation in Dynamic Environments Using Online Map Updating and Predictive Dynamic GBI-RRT"*.
It contains the framework, a differential-drive controller, the compared baselines, a 2-D simulator with three
scenarios, an experiment runner with statistics, and a ROS Noetic wrapper.

> **Status / honesty note.** This code was written from the equations of the manuscript. The numbers it produces
> in the bundled 2-D simulator come from a *synthetic* testbed and are **not** the numbers reported in the paper
> (which come from the authors' simulation and TurtleBot3 experiments). Parameters not given in Table 2 are
> documented defaults (`[assumed]` in `dynamic_gbi_rrt/config.py`).

## Layout
| Path | Content |
|---|---|
| `dynamic_gbi_rrt/mapping.py` | adaptive map updating, spatial consistency, persistence fusion, trigger (Eqs. 3, 9-16) |
| `dynamic_gbi_rrt/tracking.py` | cluster detection + Kalman tracking (Eqs. 5-8) |
| `dynamic_gbi_rrt/prediction.py` | MCI, adaptive process noise, covariance propagation, safety radius (Eqs. 17-27) |
| `dynamic_gbi_rrt/risk.py` | uncertainty-aware risk (Eqs. 31-36) |
| `dynamic_gbi_rrt/planner.py` | Dynamic GBI-RRT (Eqs. 28-30, 37-42) and an RRT* baseline planner |
| `dynamic_gbi_rrt/controller.py` | pure-pursuit controller + unicycle kinematics (v, w) |
| `dynamic_gbi_rrt/navigator.py` | integration loop (Algorithm 1); module switches for ablation |
| `dynamic_gbi_rrt/dstar_lite.py` | D* Lite (verified against Dijkstra in the tests) |
| `dynamic_gbi_rrt/baselines.py` | GBI-RRT / RRT* / D* Lite baselines and ablation variants |
| `dynamic_gbi_rrt/sim.py` | simulator, scenarios `s1_static`, `s2_corridor`, `s3_highly_dynamic`, episode runner |
| `experiments/run_benchmark.py` | comparison and ablation experiments, SR/CR/time/path/planning-time, p-values |
| `ros/dynamic_gbi_rrt_ros/` | ROS Noetic package (node, launch files, params) |
| `tests/` | unit tests |

## Quick start
```bash
pip install -r requirements.txt
python examples/demo_sim.py s3_highly_dynamic proposed     # one episode + demo_trajectory.png
python -m pytest -q                                         # unit tests
python experiments/run_benchmark.py --runs 30               # comparison with GBI-RRT, RRT*, D* Lite
python experiments/run_benchmark.py --runs 30 --ablation    # ablation (w/o AMU, prediction, PRA, EDR)
```
Outputs: `results/*_runs.csv` (per run) and `results/*_summary.md` (mean ± std, Fisher exact test for success
rate, Welch t-test for navigation time of successful runs, both against the proposed method).

## Baselines and ablation
* `gbi_rrt`: the proposed planner with all four modules switched off (static map, no prediction, no risk,
  replanning only when the path is blocked). The original GBI-RRT of Sun et al. is **not** re-implemented.
* `rrt_star`, `dstar_lite`: own implementations on the same (median-filtered) occupancy map.
* **TEB** is not part of the Python benchmark; use the ROS `teb_local_planner`
  (https://github.com/rst-tu-dortmund/teb_local_planner) via `ros/dynamic_gbi_rrt_ros/launch/baseline_teb.launch`.
* `abl_no_amu`, `abl_no_pred`, `abl_no_pra`, `abl_no_edr`: one module removed at a time.

## ROS (TurtleBot3 + slam_gmapping)
```bash
cd ~/catkin_ws/src && ln -s /path/to/repo/ros/dynamic_gbi_rrt_ros .
pip install -e /path/to/repo         # makes `dynamic_gbi_rrt` importable by the node
cd ~/catkin_ws && catkin_make && source devel/setup.bash
roslaunch dynamic_gbi_rrt_ros navigation.launch              # then set a goal with RViz "2D Nav Goal"
```
The ROS node has **not** been run in the test environment of this repository (no ROS available); expect to
adapt frames/topics to your robot. **LRBPF-SLAM** (Sun et al.) is not included: `slam_gmapping` is used as the
RBPF SLAM front end and supplies the occupancy grid.

## Known simplifications
Goal-biased RRT instead of the full GBI-RRT; kinematic pure-pursuit controller; ground-truth-based
observation model with speckle noise in the simulator instead of LiDAR + SLAM; Eq. (34) is clipped to [0, 1]
because it exceeds 1 when det(Sigma) < 1.

## License
MIT (see `LICENSE`). Add the citation of the manuscript after publication.
