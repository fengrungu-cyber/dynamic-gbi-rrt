#!/usr/bin/env python3
"""ROS Noetic node: occupancy grid (slam_gmapping) + odometry -> /cmd_vel.

Subscribes : /map (nav_msgs/OccupancyGrid), /odom (nav_msgs/Odometry),
             /move_base_simple/goal (geometry_msgs/PoseStamped, set with RViz "2D Nav Goal")
Publishes  : /cmd_vel, /dynamic_gbi_rrt/path (nav_msgs/Path)
NOTE: not executed in this repository's tests (ROS is not required for the Python benchmark).
Assumes the map frame and odometry are aligned (use the SLAM pose instead of /odom if needed).
"""
import numpy as np
import rospy
from nav_msgs.msg import OccupancyGrid, Odometry, Path
from geometry_msgs.msg import Twist, PoseStamped
from dynamic_gbi_rrt import Config, Navigator


def yaw(q):
    return np.arctan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))


class Node:
    def __init__(self):
        rospy.init_node("dynamic_gbi_rrt")
        self.cfg = Config()
        for k in vars(self.cfg):
            if rospy.has_param("~" + k):
                setattr(self.cfg, k, rospy.get_param("~" + k))
        self.nav = None; self.goal = None; self.pose = None; self.origin = np.zeros(2)
        self.grid = None
        self.pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)
        self.pub_path = rospy.Publisher("/dynamic_gbi_rrt/path", Path, queue_size=1)
        rospy.Subscriber("/map", OccupancyGrid, self.on_map, queue_size=1)
        rospy.Subscriber("/odom", Odometry, self.on_odom, queue_size=1)
        rospy.Subscriber("/move_base_simple/goal", PoseStamped, self.on_goal, queue_size=1)
        rospy.Timer(rospy.Duration(self.cfg.dt), self.on_timer)

    def on_map(self, m):
        a = np.array(m.data, dtype=float).reshape(m.info.height, m.info.width)
        p = np.where(a < 0, 0.05, a / 100.0)               # unknown treated as free
        self.cfg.resolution = m.info.resolution
        self.origin = np.array([m.info.origin.position.x, m.info.origin.position.y])
        if self.grid is None or self.grid.shape != p.shape:  # map grew: restart the framework
            self.nav = None
        self.grid = p

    def on_odom(self, o):
        q = o.pose.pose
        self.pose = np.array([q.position.x, q.position.y, yaw(q.orientation)])

    def on_goal(self, g):
        self.goal = np.array([g.pose.position.x, g.pose.position.y]); self.nav = None

    def on_timer(self, _):
        if self.grid is None or self.pose is None or self.goal is None:
            return
        local = np.array([self.pose[0] - self.origin[0], self.pose[1] - self.origin[1], self.pose[2]])
        if self.nav is None:
            self.nav = Navigator(self.grid, self.goal - self.origin, self.cfg)
        v, w, _ = self.nav.step(self.grid, local)
        if self.nav.reached(local):
            v = w = 0.0
        t = Twist(); t.linear.x, t.angular.z = v, w; self.pub.publish(t)
        if self.nav.path:
            path = Path(); path.header.frame_id = "map"; path.header.stamp = rospy.Time.now()
            for p in self.nav.path:
                ps = PoseStamped(); ps.header = path.header
                ps.pose.position.x, ps.pose.position.y = p[0] + self.origin[0], p[1] + self.origin[1]
                ps.pose.orientation.w = 1.0; path.poses.append(ps)
            self.pub_path.publish(path)


if __name__ == "__main__":
    Node(); rospy.spin()
