from setuptools import setup, find_packages
setup(name="dynamic_gbi_rrt", version="0.1.0", packages=find_packages(include=["dynamic_gbi_rrt*"]),
      install_requires=["numpy", "scipy"])
